@echo off
title MBK AI Assistant
cd /d "%~dp0"

echo ================================================================
echo   MBK AI Assistant - starting...
echo ================================================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Install it from https://www.python.org/downloads/
    echo Make sure to tick "Add Python to PATH" during install.
    echo.
    pause
    exit /b 1
)

python server.py
echo.
echo Server stopped. Press any key to close.
pause >nul