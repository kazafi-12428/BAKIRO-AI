"""
config.py
Central configuration for MBK AI Assistant.
Edit this file to change settings. Nothing else needs editing.
"""

# =====================================================================
#  AI API KEY  (OPTIONAL)
#  ------------------------------------------------------------------
#  >>> PASTE YOUR API KEY BETWEEN THE QUOTES BELOW <<<
#  Example:  AI_API_KEY = "sk-abc123..."
#
#  If you leave it as "" (empty), the assistant still works fully for:
#     - opening apps, folders, websites
#     - Google / YouTube search
#     - voice input and speech output
#  Only "general AI chat" questions will be disabled.
# =====================================================================
AI_API_KEY = ""

# OpenAI-compatible endpoint. Change only if you use another provider.
AI_API_BASE = "https://api.openai.com/v1/chat/completions"
AI_MODEL = "gpt-4o-mini"

AI_SYSTEM_PROMPT = (
    "You are MBK AI Assistant, a friendly Windows PC assistant. "
    "Answer clearly and briefly (2-4 sentences) unless asked for detail."
)

# =====================================================================
#  APPLICATION
# =====================================================================
APP_TITLE = "MBK AI Assistant"
APP_VERSION = "1.0"

GREETING = "Hello! I am MBK AI Assistant. How can I help you?"

NO_AI_MESSAGE = (
    "AI chat is not configured yet. You can still use voice commands, "
    "app opening, folders, websites and web search."
)

UNKNOWN_MESSAGE = (
    "Sorry, I didn't understand that command. Try things like "
    "'open notepad', 'open downloads', 'open youtube' or "
    "'search Python functions'."
)

# =====================================================================
#  TEXT-TO-SPEECH
# =====================================================================
VOICE_ENABLED = True      # set False to mute the assistant
VOICE_RATE = 175          # words per minute (default ~200)
VOICE_VOLUME = 1.0        # 0.0 to 1.0
VOICE_INDEX = None        # None = default Windows voice

# =====================================================================
#  SPEECH RECOGNITION (microphone)
# =====================================================================
LISTEN_TIMEOUT = 5        # seconds to wait for speech to start
PHRASE_TIME_LIMIT = 7     # max seconds of speech to record
RECOGNIZER_LANGUAGE = "en-US"

# =====================================================================
#  UI COLORS (dark theme)
# =====================================================================
COLOR_BG = "#1e1e2e"          # window background
COLOR_PANEL = "#181825"       # chat area background
COLOR_INPUT = "#313244"       # input box background
COLOR_TEXT = "#cdd6f4"        # normal text
COLOR_USER = "#89b4fa"        # "You:" label
COLOR_BOT = "#a6e3a1"         # "Assistant:" label
COLOR_SYS = "#f9e2af"         # system / status messages
COLOR_ERROR = "#f38ba8"       # errors
COLOR_BTN = "#45475a"         # button background
COLOR_BTN_ACTIVE = "#585b70"  # button hover
COLOR_ACCENT = "#89b4fa"      # accent / title