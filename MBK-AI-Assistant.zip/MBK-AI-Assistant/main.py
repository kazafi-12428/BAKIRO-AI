"""
main.py
MBK AI Assistant - Tkinter desktop GUI.

Features:
    - Dark "anime aura arc" animated background (rotating glowing arcs,
      energy rays, floating particles) drawn on a Tkinter Canvas.
    - Chat area, text input, Send / Mic / Clear buttons, status bar.
    - Voice input (background thread), text-to-speech (background thread).
    - Routes every message through assistant.respond().
    - Handles "__EXIT__" sentinel from commands.py to close the app.
"""

import math
import random
import threading
import tkinter as tk

import config
import assistant
import speech
import voice


class MBKAssistant:

    def __init__(self, root):
        self.root = root
        self.root.title("{}  v{}".format(config.APP_TITLE, config.APP_VERSION))
        self.root.geometry("900x700")
        self.root.minsize(760, 600)
        self.root.configure(bg=config.COLOR_BG)

        # ---- animation state -------------------------------------------
        self.angle = 0.0
        self.listening = False
        self.particles = []
        for _ in range(45):
            self.particles.append({
                "x": random.uniform(0, 900),
                "y": random.uniform(0, 700),
                "vy": random.uniform(-0.7, -0.25),
                "r": random.uniform(1.0, 2.6),
                "color": random.choice(
                    ["#89b4fa", "#cba6f7", "#f5c2e7", "#94e2d5", "#fab387"]
                ),
            })

        # ---- background canvas ----------------------------------------
        self.canvas = tk.Canvas(self.root, bg=config.COLOR_BG,
                                highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", self._on_canvas_resize)

        # ---- build widgets --------------------------------------------
        self._build_title()
        self._build_chat()
        self._build_input()
        self._build_status()

        # ---- startup --------------------------------------------------
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(60, self._animate)
        self.root.after(150, self._draw_title)
        self.root.after(250, self._say_hello)
        self.entry.focus_set()

    # =================================================================
    #  UI CONSTRUCTION
    # =================================================================
    def _build_title(self):
        """Title is a canvas text item so the aura shows behind it."""
        self.title_id = None
        self.subtitle_id = None

    def _draw_title(self):
        w = self.canvas.winfo_width()
        if w < 50:
            self.root.after(80, self._draw_title)
            return
        if self.title_id:
            self.canvas.delete(self.title_id)
        if self.subtitle_id:
            self.canvas.delete(self.subtitle_id)
        self.title_id = self.canvas.create_text(
            w / 2, 42,
            text="MBK AI Assistant",
            fill=config.COLOR_ACCENT,
            font=("Segoe UI", 22, "bold"),
        )
        self.subtitle_id = self.canvas.create_text(
            w / 2, 72,
            text="Voice + Chat  •  PC Control  •  Web Search",
            fill="#7f849c",
            font=("Segoe UI", 10),
        )

    def _build_chat(self):
        self.chat = tk.Text(
            self.canvas,
            bg=config.COLOR_PANEL,
            fg=config.COLOR_TEXT,
            insertbackground=config.COLOR_TEXT,
            font=("Segoe UI", 11),
            wrap="word",
            bd=0,
            relief="flat",
            padx=16,
            pady=14,
            state="disabled",
            highlightthickness=1,
            highlightbackground="#313244",
            highlightcolor="#313244",
        )
        self.chat.place(relx=0.04, rely=0.14, relwidth=0.92, relheight=0.62)

        # tag colors
        self.chat.tag_config("user", foreground=config.COLOR_USER,
                             font=("Segoe UI", 11, "bold"))
        self.chat.tag_config("bot", foreground=config.COLOR_BOT,
                             font=("Segoe UI", 11, "bold"))
        self.chat.tag_config("sys", foreground=config.COLOR_SYS,
                             font=("Segoe UI", 10, "italic"))
        self.chat.tag_config("err", foreground=config.COLOR_ERROR,
                             font=("Segoe UI", 10, "italic"))

    def _build_input(self):
        frame = tk.Frame(self.canvas, bg=config.COLOR_BG)
        frame.place(relx=0.04, rely=0.79, relwidth=0.92, relheight=0.09)

        self.entry = tk.Entry(
            frame,
            bg=config.COLOR_INPUT,
            fg=config.COLOR_TEXT,
            insertbackground=config.COLOR_ACCENT,
            font=("Segoe UI", 12),
            bd=0,
            relief="flat",
            highlightthickness=1,
            highlightbackground="#313244",
            highlightcolor=config.COLOR_ACCENT,
        )
        self.entry.pack(side="left", fill="both", expand=True,
                        padx=(0, 8), ipady=10)
        self.entry.bind("<Return>", lambda e: self._on_send())

        btn_style = dict(
            bg=config.COLOR_BTN,
            fg=config.COLOR_TEXT,
            bd=0,
            relief="flat",
            activebackground=config.COLOR_BTN_ACTIVE,
            activeforeground=config.COLOR_TEXT,
            font=("Segoe UI", 11, "bold"),
            cursor="hand2",
            padx=16,
            pady=8,
            highlightthickness=0,
        )

        self.send_btn = tk.Button(frame, text="Send",
                                  command=self._on_send, **btn_style)
        self.send_btn.pack(side="left")

        self.mic_btn = tk.Button(frame, text="🎤",
                                 command=self._on_mic, **btn_style)
        self.mic_btn.pack(side="left", padx=(6, 0))

        self.clear_btn = tk.Button(frame, text="Clear",
                                   command=self._on_clear, **btn_style)
        self.clear_btn.pack(side="left", padx=(6, 0))

    def _build_status(self):
        self.status_var = tk.StringVar(value="Ready")
        bar = tk.Frame(self.canvas, bg=config.COLOR_BG)
        bar.place(relx=0.04, rely=0.90, relwidth=0.92, relheight=0.05)

        tk.Label(bar, text="●", bg=config.COLOR_BG,
                 fg=config.COLOR_BOT, font=("Segoe UI", 11)).pack(side="left")

        tk.Label(bar, textvariable=self.status_var, bg=config.COLOR_BG,
                 fg=config.COLOR_SYS, font=("Segoe UI", 10),
                 anchor="w").pack(side="left", padx=(6, 0))

        tk.Label(bar,
                 text="Type  'open notepad'  or  click 🎤",
                 bg=config.COLOR_BG, fg="#6c7086",
                 font=("Segoe UI", 9, "italic")).pack(side="right")

    # =================================================================
    #  ANIME AURA BACKGROUND
    # =================================================================
    def _on_canvas_resize(self, event):
        self._draw_title()

    def _animate(self):
        self.angle = (self.angle + 1.8) % 360.0
        self._render_aura()
        self.root.after(40, self._animate)

    def _render_aura(self):
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        if w < 40 or h < 40:
            return

        self.canvas.delete("aura")
        self.canvas.delete("particle")

        cx = w / 2.0
        cy = h / 2.0
        base = min(w, h)

        # ---- rings: (radius fraction, width, color) --------------------
        rings = [
            (0.46, 7, "#89b4fa"),
            (0.40, 6, "#cba6f7"),
            (0.34, 5, "#f5c2e7"),
            (0.28, 4, "#94e2d5"),
            (0.22, 3, "#fab387"),
        ]

        for i, (frac, width, color) in enumerate(rings):
            r = base * frac
            start = (self.angle * (1 + i * 0.25) + i * 55) % 360

            # main rotating arc
            self.canvas.create_arc(
                cx - r, cy - r, cx + r, cy + r,
                start=start, extent=150,
                style="arc", outline=color, width=width,
                tags="aura",
            )
            # mirrored glow arc (stipple fakes transparency)
            self.canvas.create_arc(
                cx - r, cy - r, cx + r, cy + r,
                start=start + 180, extent=95,
                style="arc", outline=color,
                width=max(1, width - 2),
                stipple="gray50", tags="aura",
            )
            # faint trailing arc
            self.canvas.create_arc(
                cx - r, cy - r, cx + r, cy + r,
                start=start + 275, extent=45,
                style="arc", outline=color,
                width=max(1, width - 3),
                stipple="gray25", tags="aura",
            )

        # ---- energy rays radiating from center ------------------------
        n_rays = 10
        for i in range(n_rays):
            ang = math.radians((self.angle * 2.2) + i * (360.0 / n_rays))
            r1 = base * 0.18
            r2 = base * 0.50
            x1 = cx + math.cos(ang) * r1
            y1 = cy + math.sin(ang) * r1
            x2 = cx + math.cos(ang) * r2
            y2 = cy + math.sin(ang) * r2
            self.canvas.create_line(
                x1, y1, x2, y2,
                fill="#cba6f7", width=1,
                stipple="gray25", tags="aura",
            )

        # ---- floating particles --------------------------------------
        for p in self.particles:
            p["y"] += p["vy"]
            if p["y"] < -6:
                p["y"] = h + 6
                p["x"] = random.uniform(0, w)
            self.canvas.create_oval(
                p["x"] - p["r"], p["y"] - p["r"],
                p["x"] + p["r"], p["y"] + p["r"],
                fill=p["color"], outline="",
                stipple="gray50", tags="particle",
            )

        # keep title on top of aura
        self.canvas.tag_raise("title" if self.title_id else "none")
        if self.title_id:
            self.canvas.tag_raise(self.title_id)
        if self.subtitle_id:
            self.canvas.tag_raise(self.subtitle_id)

    # =================================================================
    #  CHAT HELPERS
    # =================================================================
    def _add_message(self, who, text, tag=None):
        if not text:
            return
        self.chat.configure(state="normal")
        if who == "You":
            self.chat.insert("end", "You: ", "user")
            self.chat.insert("end", str(text) + "\n\n")
        elif who == "Assistant":
            self.chat.insert("end", "Assistant: ", "bot")
            self.chat.insert("end", str(text) + "\n\n")
        else:
            self.chat.insert("end", str(text) + "\n\n", tag or "sys")
        self.chat.see("end")
        self.chat.configure(state="disabled")

    def _set_status(self, text):
        try:
            self.status_var.set(text)
        except Exception:
            pass

    def _say_hello(self):
        self._add_message("Assistant", config.GREETING)
        speech.speak(config.GREETING)

    # =================================================================
    #  SEND / PROCESS
    # =================================================================
    def _on_send(self):
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, "end")
        self._add_message("You", text)
        self._process(text)

    def _process(self, text):
        self._set_status("Thinking...")
        t = threading.Thread(target=self._process_worker, args=(text,),
                             daemon=True)
        t.start()

    def _process_worker(self, text):
        try:
            reply = assistant.respond(text)
        except Exception as e:
            reply = "Sorry, something went wrong: {}".format(e)
        self.root.after(0, lambda: self._handle_reply(reply))

    def _handle_reply(self, reply):
        if reply == "__EXIT__":
            self._add_message("Assistant", "Goodbye!", "sys")
            speech.speak("Goodbye!")
            self.root.after(700, self._on_close)
            return
        self._add_message("Assistant", reply)
        # Speak short, important replies (avoid reading huge AI paragraphs)
        if reply and len(reply) <= 320:
            speech.speak(reply)
        else:
            speech.speak("Here is what I found.")
        self._set_status("Ready")

    # =================================================================
    #  MICROPHONE
    # =================================================================
    def _on_mic(self):
        if self.listening:
            return
        if not voice.is_available():
            self._add_message(
                "System",
                "SpeechRecognition is not installed. Run: pip install SpeechRecognition",
                "err",
            )
            speech.speak("Voice input is not available.")
            return

        self.listening = True
        try:
            self.mic_btn.configure(state="disabled", text="...")
        except Exception:
            pass
        self._set_status("Listening...")
        threading.Thread(target=self._mic_worker, daemon=True).start()

    def _mic_worker(self):
        try:
            text, err = voice.listen()
        except Exception as e:
            text, err = "", "Voice error: {}".format(e)
        self.root.after(0, lambda: self._mic_done(text, err))

    def _mic_done(self, text, err):
        self.listening = False
        try:
            self.mic_btn.configure(state="normal", text="🎤")
        except Exception:
            pass

        if err:
            self._add_message("System", err, "err")
            self._set_status("Ready")
            short = err if len(err) <= 90 else "I couldn't understand that."
            speech.speak(short)
            return

        if text:
            self.entry.delete(0, "end")
            self.entry.insert(0, text)
            self._add_message("You", text + "   (voice)")
            self._process(text)
        else:
            self._set_status("Ready")

    # =================================================================
    #  CLEAR / CLOSE
    # =================================================================
    def _on_clear(self):
        self.chat.configure(state="normal")
        self.chat.delete("1.0", "end")
        self.chat.configure(state="disabled")
        self._add_message("Assistant", config.GREETING)
        self._set_status("Ready")

    def _on_close(self):
        try:
            speech.shutdown()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass


# =====================================================================
#  ENTRY POINT
# =====================================================================
def main():
    root = tk.Tk()
    try:
        MBKAssistant(root)
    except Exception as e:
        # Never leave the user with a silent crash
        import traceback
        traceback.print_exc()
        try:
            from tkinter import messagebox
            messagebox.showerror("MBK AI Assistant", "Startup error:\n\n{}".format(e))
        except Exception:
            pass
        raise
    root.mainloop()


if __name__ == "__main__":
    main()