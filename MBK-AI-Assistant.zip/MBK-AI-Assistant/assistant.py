"""
assistant.py
The "brain" of MBK AI Assistant.

Flow for every user message:
    1. Try commands.py  (PC control: apps, folders, sites, search)
    2. If a key is set, try the AI API
    3. Otherwise, answer using a small built-in offline knowledge base
    4. If nothing matches, return a friendly fallback

Returns plain strings. Never raises.
"""

import json
import urllib.request
import urllib.error

import config
import commands


# =====================================================================
#  OFFLINE KNOWLEDGE BASE
#  Small curated set of topics so "what is Python?" etc. work
#  without any API key. Keys are lowercase keywords to match.
# =====================================================================
KNOWLEDGE = {
    "python": (
        "Python is a high-level, interpreted programming language known for "
        "its readable syntax. It's widely used for web development, data "
        "science, automation, AI, and scripting. You write a script like "
        "'print(\"Hello\")' and run it with 'python file.py'."
    ),
    "cybersecurity": (
        "Cybersecurity is the practice of protecting computers, networks, and "
        "data from digital attacks. It covers areas like network security, "
        "encryption, access control, and threat detection. Common goals are "
        "confidentiality, integrity, and availability (the CIA triad)."
    ),
    "java": (
        "Java is a class-based, object-oriented programming language that runs "
        "on the Java Virtual Machine (JVM). It's popular for Android apps, "
        "enterprise backends, and large systems because of its portability."
    ),
    "javascript": (
        "JavaScript is the language of the web. It runs in browsers to make "
        "pages interactive, and with Node.js it can also run on servers. It's "
        "one of the most widely used languages in the world."
    ),
    "html": (
        "HTML (HyperText Markup Language) is the standard language for "
        "creating web pages. It uses tags like <h1>, <p>, and <a> to structure "
        "content. It works together with CSS (styling) and JavaScript (behavior)."
    ),
    "css": (
        "CSS (Cascading Style Sheets) controls how web pages look - colors, "
        "layout, fonts, spacing. It's used alongside HTML to style a page."
    ),
    "machine learning": (
        "Machine learning is a branch of AI where computers learn patterns from "
        "data instead of being explicitly programmed. Common types are "
        "supervised, unsupervised, and reinforcement learning."
    ),
    "artificial intelligence": (
        "Artificial intelligence (AI) is the field of building machines that "
        "can perform tasks requiring human-like intelligence - understanding "
        "language, recognizing images, making decisions, and learning."
    ),
    "ai": (
        "AI stands for Artificial Intelligence - the field of building machines "
        "that can perform tasks that normally need human intelligence, like "
        "understanding language, recognizing images, and making decisions."
    ),
    "database": (
        "A database is an organized collection of data that can be easily "
        "accessed, managed, and updated. Common types are relational (MySQL, "
        "PostgreSQL) and NoSQL (MongoDB, Redis)."
    ),
    "operating system": (
        "An operating system (OS) is the software that manages hardware and "
        "lets other programs run. Examples include Windows, Linux, macOS, "
        "Android, and iOS."
    ),
    "algorithm": (
        "An algorithm is a step-by-step set of instructions for solving a "
        "problem or completing a task. Sorting, searching, and pathfinding "
        "are classic examples."
    ),
    "network": (
        "A computer network is a group of devices connected so they can share "
        "data and resources. The internet is the largest network, using the "
        "TCP/IP protocol suite."
    ),
    "internet": (
        "The internet is a global network of interconnected computers that "
        "communicate using TCP/IP. The World Wide Web (websites) runs on top "
        "of it."
    ),
    "api": (
        "An API (Application Programming Interface) is a set of rules that lets "
        "one program talk to another. For example, a weather API lets your app "
        "fetch today's forecast without knowing how the weather service works."
    ),
    "git": (
        "Git is a distributed version control system. It tracks changes to "
        "files so you can revert, branch, and collaborate. GitHub and GitLab "
        "are popular hosting platforms for Git repositories."
    ),
    "linux": (
        "Linux is a free, open-source operating system kernel used by many "
        "distributions like Ubuntu, Fedora, and Debian. It powers most servers "
        "and Android phones."
    ),
    "windows": (
        "Windows is Microsoft's operating system for PCs. Recent versions "
        "include Windows 10 and Windows 11. It uses the NT kernel and supports "
        "a huge range of software."
    ),
    "quantum computing": (
        "Quantum computing uses quantum bits (qubits) that can be 0 and 1 at "
        "the same time. This lets certain problems - like factoring and "
        "simulation - be solved much faster than with classical computers."
    ),
    "blockchain": (
        "A blockchain is a distributed, tamper-resistant ledger. Each block "
        "contains transactions and a cryptographic link to the previous block. "
        "It underpins cryptocurrencies like Bitcoin."
    ),
    "cloud computing": (
        "Cloud computing means using computing resources (servers, storage, "
        "databases) over the internet instead of owning them. Big providers "
        "include AWS, Microsoft Azure, and Google Cloud."
    ),
    "html5": (
        "HTML5 is the latest major version of HTML. It adds semantic tags, "
        "native audio/video, canvas graphics, and better form controls."
    ),
    "sql": (
        "SQL (Structured Query Language) is used to work with relational "
        "databases. You use it to SELECT, INSERT, UPDATE, and DELETE data."
    ),
    "hello": (
        "Hello! I'm MBK AI Assistant. Try 'open notepad', 'open youtube', or "
        "ask me 'what is Python?'."
    ),
    "how are you": (
        "I'm running great, thanks for asking! What can I help you with?"
    ),
    "your name": (
        "I'm MBK AI Assistant, your Windows PC helper."
    ),
    "who are you": (
        "I'm MBK AI Assistant - I can open apps, folders and websites, search "
        "the web, and answer simple questions."
    ),
    "thank": (
        "You're welcome! Anything else I can do?"
    ),
}


# =====================================================================
#  OFFLINE MATCHER
# =====================================================================
def _offline_answer(text):
    """Look for a keyword in the knowledge base. Returns answer or None."""
    low = text.lower()

    # Longest key first so "machine learning" beats "learning"
    for key in sorted(KNOWLEDGE.keys(), key=len, reverse=True):
        if key in low:
            return KNOWLEDGE[key]
    return None


# =====================================================================
#  AI API (optional)
# =====================================================================
def _has_api_key():
    key = (config.AI_API_KEY or "").strip()
    return bool(key)


def _ask_ai(text):
    """
    Send the message to an OpenAI-compatible chat endpoint.
    Returns the reply text, or None if it fails (caller falls back).
    """
    if not _has_api_key():
        return None

    payload = {
        "model": config.AI_MODEL,
        "messages": [
            {"role": "system", "content": config.AI_SYSTEM_PROMPT},
            {"role": "user", "content": text},
        ],
        "temperature": 0.7,
        "max_tokens": 400,
    }

    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            config.AI_API_BASE,
            data=data,
            headers={
                "Content-Type": "application/json",
                "Authorization": "Bearer " + config.AI_API_KEY.strip(),
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=25) as resp:
            body = resp.read().decode("utf-8")
        parsed = json.loads(body)
        return parsed["choices"][0]["message"]["content"].strip()
    except urllib.error.HTTPError as e:
        try:
            err_body = e.read().decode("utf-8")
        except Exception:
            err_body = str(e)
        return "(AI error {}: {})".format(e.code, err_body[:200])
    except urllib.error.URLError as e:
        return "(AI network error: {})".format(e.reason)
    except Exception as e:
        return "(AI error: {})".format(e)


# =====================================================================
#  PUBLIC ENTRY
# =====================================================================
def respond(user_text):
    """
    Given the user's message, return the assistant's reply as a plain string.
    Never raises. If the reply is the sentinel "__EXIT__", main.py will quit.
    """
    if not user_text:
        return config.UNKNOWN_MESSAGE

    text = user_text.strip()
    if not text:
        return config.UNKNOWN_MESSAGE

    # 1) PC commands first
    try:
        handled, reply = commands.process(text)
    except Exception as e:
        handled, reply = False, ""
        # don't crash on weird input; log to the reply so it's visible
        print("commands.process error:", e)

    if handled:
        return reply

    # 2) AI API if configured
    if _has_api_key():
        ai = _ask_ai(text)
        if ai:
            return ai

    # 3) Offline knowledge base
    offline = _offline_answer(text)
    if offline:
        return offline

    # 4) Fallback
    if not _has_api_key():
        return config.NO_AI_MESSAGE
    return config.UNKNOWN_MESSAGE