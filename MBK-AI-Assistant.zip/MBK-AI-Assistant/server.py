"""
server.py
MBK AI Assistant - local web server.

Serves index.html and exposes POST /api/command so the browser can
ask Python to actually launch apps and folders (something a browser
alone cannot do).

Uses ONLY Python's standard library. No pip install needed.
Binds to 127.0.0.1 only - never exposed to your network.
"""

import json
import mimetypes
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import config
import assistant

HOST = "127.0.0.1"
PORT = 8765
BASE_DIR = Path(__file__).resolve().parent
INDEX_FILE = BASE_DIR / "index.html"


class Handler(BaseHTTPRequestHandler):
    # Silence per-request console spam
    def log_message(self, fmt, *args):
        pass

    # ---------------- helpers ----------------
    def _send_json(self, obj, status=200):
        data = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(data)
        except Exception:
            pass

    def _send_file(self, path: Path):
        try:
            data = path.read_bytes()
        except Exception:
            self._send_json({"error": "not found"}, 404)
            return
        ctype, _ = mimetypes.guess_type(str(path))
        ctype = ctype or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        try:
            self.wfile.write(data)
        except Exception:
            pass

    # ---------------- routes ----------------
    def do_GET(self):
        # Strip query string
        rel = self.path.split("?", 1)[0]

        if rel in ("/", "/index.html"):
            self._send_file(INDEX_FILE)
            return

        # Serve other static files (favicon, css, js...) safely
        candidate = (BASE_DIR / rel.lstrip("/")).resolve()
        try:
            candidate.relative_to(BASE_DIR)
        except ValueError:
            self._send_json({"error": "forbidden"}, 403)
            return

        if candidate.is_file():
            self._send_file(candidate)
        else:
            self._send_json({"error": "not found"}, 404)

    def do_POST(self):
        if self.path != "/api/command":
            self._send_json({"error": "not found"}, 404)
            return

        # Read JSON body
        try:
            length = int(self.headers.get("Content-Length", "0") or "0")
            raw = self.rfile.read(length) if length else b"{}"
            payload = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            self._send_json({"error": "bad request"}, 400)
            return

        text = str(payload.get("text", "")).strip()
        if not text:
            self._send_json({"reply": "", "exit": False})
            return

        # Run through the same brain as the desktop app
        try:
            reply = assistant.respond(text)
        except Exception as e:
            reply = "Sorry, something went wrong: {}".format(e)

        is_exit = (reply == "__EXIT__")
        if is_exit:
            reply = "Goodbye!"

        self._send_json({"reply": reply, "exit": is_exit})


def _open_browser_soon(url):
    def _go():
        import time
        time.sleep(0.7)
        try:
            webbrowser.open(url)
        except Exception:
            pass
    threading.Thread(target=_go, daemon=True).start()


def main():
    if not INDEX_FILE.exists():
        print("ERROR: index.html not found next to server.py")
        print("Expected at:", INDEX_FILE)
        sys.exit(1)

    url = "http://{}:{}/".format(HOST, PORT)

    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as e:
        print("Could not start server on {}".format(url))
        print("Reason:", e)
        print("Tip: another program may be using port {}. Close it and retry.".format(PORT))
        sys.exit(1)

    print("=" * 62)
    print("  MBK AI Assistant  -  Web Edition")
    print("=" * 62)
    print("  Server:       {}".format(url))
    print("  Launching browser...")
    print("  Stop server:  press Ctrl + C in this window")
    print("=" * 62)

    _open_browser_soon(url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        try:
            server.server_close()
        except Exception:
            pass


if __name__ == "__main__":
    main()