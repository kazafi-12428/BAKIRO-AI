"""
speech.py
Text-to-speech engine for MBK AI Assistant.

Uses pyttsx3 (offline, uses Windows SAPI5 voices).
Runs on a background daemon thread with a queue
so the Tkinter GUI never freezes while speaking.
"""

import threading
import queue
import config

# ---- optional dependency ------------------------------------------------
try:
    import pyttsx3
    _TTS_AVAILABLE = True
except ImportError:
    _TTS_AVAILABLE = False

# ---- internal state -----------------------------------------------------
_queue = queue.Queue()
_worker_started = False
_lock = threading.Lock()


def _worker():
    """Background thread: pull text from queue and speak it."""
    engine = None

    if _TTS_AVAILABLE:
        try:
            engine = pyttsx3.init()
            engine.setProperty("rate", config.VOICE_RATE)
            engine.setProperty("volume", config.VOICE_VOLUME)

            # Optional: pick a specific voice by index
            if config.VOICE_INDEX is not None:
                try:
                    voices = engine.getProperty("voices")
                    if 0 <= config.VOICE_INDEX < len(voices):
                        engine.setProperty("voice", voices[config.VOICE_INDEX].id)
                except Exception:
                    pass
        except Exception:
            # If the engine can't start, we still run the worker quietly
            engine = None

    while True:
        text = _queue.get()
        if text is None:            # shutdown signal
            break
        if engine is not None and config.VOICE_ENABLED:
            try:
                engine.say(text)
                engine.runAndWait()
            except Exception:
                # Never crash the worker because of a TTS hiccup
                pass
        _queue.task_done()


def _ensure_worker():
    """Start the worker thread once, on first use."""
    global _worker_started
    with _lock:
        if not _worker_started:
            t = threading.Thread(target=_worker, daemon=True)
            t.start()
            _worker_started = True


def speak(text):
    """
    Queue text to be spoken in the background.
    Returns immediately - never blocks the GUI.
    """
    if not text:
        return
    if not config.VOICE_ENABLED:
        return
    _ensure_worker()
    _queue.put(str(text))


def shutdown():
    """Cleanly stop the speech worker (called when app closes)."""
    if _worker_started:
        try:
            _queue.put(None)
        except Exception:
            pass


def is_available():
    """True if pyttsx3 is installed and could be imported."""
    return _TTS_AVAILABLE