"""
voice.py
Microphone -> text for MBK AI Assistant.

Uses the SpeechRecognition package with Google's free Web Speech API.
Every failure mode returns a friendly (text, error) tuple so the GUI
never crashes, even if the microphone or internet is unavailable.
"""

import config

# ---- optional dependency ------------------------------------------------
try:
    import speech_recognition as sr
    _SR_AVAILABLE = True
except ImportError:
    _SR_AVAILABLE = False

_recognizer = None


def _get_recognizer():
    """Create the recognizer lazily so import never fails."""
    global _recognizer
    if not _SR_AVAILABLE:
        return None
    if _recognizer is None:
        _recognizer = sr.Recognizer()
        _recognizer.dynamic_energy_threshold = True
        _recognizer.pause_threshold = 0.8
    return _recognizer


def is_available():
    """True if the speech_recognition package is installed."""
    return _SR_AVAILABLE


def listen():
    """
    Listen once from the default microphone.

    Returns a tuple: (text, error)
        text  : recognized string, or "" on failure
        error : None on success, otherwise a short human-readable reason
    """
    if not _SR_AVAILABLE:
        return "", "SpeechRecognition is not installed. Run: pip install SpeechRecognition"

    rec = _get_recognizer()

    # ---- access the microphone ----------------------------------------
    try:
        mic = sr.Microphone()
    except Exception as e:
        return "", "No microphone found: {}".format(e)

    try:
        with mic as source:
            # Calibrate quickly for ambient noise
            try:
                rec.adjust_for_ambient_noise(source, duration=0.4)
            except Exception:
                pass

            # ---- listen ------------------------------------------------
            try:
                audio = rec.listen(
                    source,
                    timeout=config.LISTEN_TIMEOUT,
                    phrase_time_limit=config.PHRASE_TIME_LIMIT,
                )
            except sr.WaitTimeoutError:
                return "", "I didn't hear anything. Please try again."
            except Exception as e:
                return "", "Microphone error: {}".format(e)

    except Exception as e:
        return "", "Microphone unavailable: {}".format(e)

    # ---- recognize -----------------------------------------------------
    try:
        text = rec.recognize_google(audio, language=config.RECOGNIZER_LANGUAGE)
        return text.strip(), None
    except sr.UnknownValueError:
        return "", "I couldn't understand that. Please try again."
    except sr.RequestError as e:
        return "", "Speech service unavailable (check internet): {}".format(e)
    except Exception as e:
        return "", "Recognition error: {}".format(e)