"""
commands.py
Safe command processor for MBK AI Assistant.

Every PC action is whitelisted. Unknown text is NEVER passed to the shell.
Returns (handled: bool, reply: str).
"""

import os
import subprocess
import webbrowser
from pathlib import Path

HOME = Path.home()
LOCAL = os.path.expandvars(r"%LOCALAPPDATA%")
PROGF = r"C:\Program Files"
PROGX = r"C:\Program Files (x86)"

# =====================================================================
#  APPLICATION WHITELIST
# =====================================================================
APPS = {
    # --- Built-in Windows tools (always present) ---
    "notepad":         {"exe": "notepad.exe",       "paths": [], "url": None, "reply": "Opening Notepad."},
    "calculator":      {"exe": "calc.exe",          "paths": [], "url": None, "reply": "Opening Calculator."},
    "calc":            {"exe": "calc.exe",          "paths": [], "url": None, "reply": "Opening Calculator."},
    "command prompt":  {"exe": "cmd.exe",           "paths": [], "url": None, "reply": "Opening Command Prompt."},
    "cmd":             {"exe": "cmd.exe",           "paths": [], "url": None, "reply": "Opening Command Prompt."},
    "powershell":      {"exe": "powershell.exe",    "paths": [], "url": None, "reply": "Opening PowerShell."},
    "file explorer":   {"exe": "explorer.exe",      "paths": [], "url": None, "reply": "Opening File Explorer."},
    "explorer":        {"exe": "explorer.exe",      "paths": [], "url": None, "reply": "Opening File Explorer."},
    "paint":           {"exe": "mspaint.exe",       "paths": [], "url": None, "reply": "Opening Paint."},
    "task manager":    {"exe": "taskmgr.exe",       "paths": [], "url": None, "reply": "Opening Task Manager."},
    "wordpad":         {"exe": "write.exe",         "paths": [], "url": None, "reply": "Opening WordPad."},
    "control panel":   {"exe": "control.exe",       "paths": [], "url": None, "reply": "Opening Control Panel."},
    "snipping tool":   {"exe": "snippingtool.exe",  "paths": [], "url": None, "reply": "Opening Snipping Tool."},
    "sticky notes":    {"exe": "notepad.exe",       "paths": [], "url": None, "reply": "Opening Sticky Notes (via Notepad)."},
    "settings":        {"exe": "ms-settings:",      "paths": [], "url": None, "reply": "Opening Windows Settings."},
    "store":           {"exe": "ms-windows-store:", "paths": [], "url": None, "reply": "Opening Microsoft Store."},
    "camera":          {"exe": "microsoft.windows.camera:", "paths": [], "url": None, "reply": "Opening Camera."},

    # --- Browsers ---
    "chrome": {
        "exe": "chrome.exe",
        "paths": [
            PROGF + r"\Google\Chrome\Application\chrome.exe",
            PROGX + r"\Google\Chrome\Application\chrome.exe",
            LOCAL + r"\Google\Chrome\Application\chrome.exe",
        ],
        "url": "https://www.google.com",
        "reply": "Opening Chrome.",
    },
    "google chrome": {
        "exe": "chrome.exe",
        "paths": [
            PROGF + r"\Google\Chrome\Application\chrome.exe",
            PROGX + r"\Google\Chrome\Application\chrome.exe",
            LOCAL + r"\Google\Chrome\Application\chrome.exe",
        ],
        "url": "https://www.google.com",
        "reply": "Opening Google Chrome.",
    },
    "edge": {
        "exe": "msedge.exe",
        "paths": [
            PROGX + r"\Microsoft\Edge\Application\msedge.exe",
            PROGF + r"\Microsoft\Edge\Application\msedge.exe",
        ],
        "url": "https://www.bing.com",
        "reply": "Opening Microsoft Edge.",
    },
    "microsoft edge": {
        "exe": "msedge.exe",
        "paths": [
            PROGX + r"\Microsoft\Edge\Application\msedge.exe",
            PROGF + r"\Microsoft\Edge\Application\msedge.exe",
        ],
        "url": "https://www.bing.com",
        "reply": "Opening Microsoft Edge.",
    },
    "firefox": {
        "exe": "firefox.exe",
        "paths": [
            PROGF + r"\Mozilla Firefox\firefox.exe",
            PROGX + r"\Mozilla Firefox\firefox.exe",
        ],
        "url": "https://www.mozilla.org",
        "reply": "Opening Firefox.",
    },

    # --- Microsoft Office ---
    "word": {
        "exe": "winword.exe",
        "paths": [
            PROGF + r"\Microsoft Office\root\Office16\WINWORD.EXE",
            PROGX + r"\Microsoft Office\root\Office16\WINWORD.EXE",
        ],
        "url": "https://www.office.com",
        "reply": "Opening Word.",
    },
    "excel": {
        "exe": "excel.exe",
        "paths": [
            PROGF + r"\Microsoft Office\root\Office16\EXCEL.EXE",
            PROGX + r"\Microsoft Office\root\Office16\EXCEL.EXE",
        ],
        "url": "https://www.office.com",
        "reply": "Opening Excel.",
    },
    "powerpoint": {
        "exe": "powerpnt.exe",
        "paths": [
            PROGF + r"\Microsoft Office\root\Office16\POWERPNT.EXE",
            PROGX + r"\Microsoft Office\root\Office16\POWERPNT.EXE",
        ],
        "url": "https://www.office.com",
        "reply": "Opening PowerPoint.",
    },
    "outlook": {
        "exe": "outlook.exe",
        "paths": [
            PROGF + r"\Microsoft Office\root\Office16\OUTLOOK.EXE",
            PROGX + r"\Microsoft Office\root\Office16\OUTLOOK.EXE",
        ],
        "url": "https://outlook.live.com",
        "reply": "Opening Outlook.",
    },
    "onenote": {
        "exe": "onenote.exe",
        "paths": [
            PROGF + r"\Microsoft Office\root\Office16\ONENOTE.EXE",
            PROGX + r"\Microsoft Office\root\Office16\ONENOTE.EXE",
        ],
        "url": "https://www.onenote.com",
        "reply": "Opening OneNote.",
    },

    # --- Dev tools ---
    "vs code": {
        "exe": "code.cmd",
        "paths": [
            LOCAL + r"\Programs\Microsoft VS Code\Code.exe",
            PROGF + r"\Microsoft VS Code\Code.exe",
        ],
        "url": "https://code.visualstudio.com",
        "reply": "Opening VS Code.",
    },
    "vscode": {
        "exe": "code.cmd",
        "paths": [
            LOCAL + r"\Programs\Microsoft VS Code\Code.exe",
            PROGF + r"\Microsoft VS Code\Code.exe",
        ],
        "url": "https://code.visualstudio.com",
        "reply": "Opening VS Code.",
    },
    "notepad++": {
        "exe": "notepad++.exe",
        "paths": [
            PROGF + r"\Notepad++\notepad++.exe",
            PROGX + r"\Notepad++\notepad++.exe",
        ],
        "url": None,
        "reply": "Opening Notepad++.",
    },
    "windows terminal": {
        "exe": "wt.exe",
        "paths": [],
        "url": None,
        "reply": "Opening Windows Terminal.",
    },

    # --- Media / chat apps ---
    "vlc": {
        "exe": "vlc.exe",
        "paths": [
            PROGF + r"\VideoLAN\VLC\vlc.exe",
            PROGX + r"\VideoLAN\VLC\vlc.exe",
        ],
        "url": None,
        "reply": "Opening VLC.",
    },
    "spotify": {
        "exe": "Spotify.exe",
        "paths": [
            os.path.expandvars(r"%APPDATA%\Spotify\Spotify.exe"),
            LOCAL + r"\Microsoft\WindowsApps\Spotify.exe",
        ],
        "url": "https://open.spotify.com",
        "reply": "Opening Spotify.",
    },
    "discord": {
        "exe": "Discord.exe",
        "paths": [
            LOCAL + r"\Discord\app-1.0.0\Discord.exe",
        ],
        "url": "https://discord.com/app",
        "reply": "Opening Discord.",
    },
    "steam": {
        "exe": "steam.exe",
        "paths": [
            PROGF + r"\Steam\steam.exe",
            PROGX + r"\Steam\steam.exe",
        ],
        "url": "https://store.steampowered.com",
        "reply": "Opening Steam.",
    },
    "whatsapp": {
        "exe": "WhatsApp.exe",
        "paths": [
            LOCAL + r"\WhatsApp\WhatsApp.exe",
            LOCAL + r"\Microsoft\WindowsApps\WhatsApp.exe",
        ],
        "url": "https://web.whatsapp.com",
        "reply": "Opening WhatsApp.",
    },
    "telegram": {
        "exe": "Telegram.exe",
        "paths": [
            os.path.expandvars(r"%APPDATA%\Telegram Desktop\Telegram.exe"),
        ],
        "url": "https://web.telegram.org",
        "reply": "Opening Telegram.",
    },
}

# =====================================================================
#  FOLDER WHITELIST (relative to user's home)
# =====================================================================
FOLDERS = {
    "downloads": "Downloads", "download": "Downloads",
    "documents": "Documents", "document": "Documents",
    "desktop": "Desktop",
    "pictures": "Pictures", "photos": "Pictures",
    "videos": "Videos",
    "music": "Music",
    "home": "", "user folder": "",
}

# =====================================================================
#  WEBSITE WHITELIST
# =====================================================================
WEBSITES = {
    "youtube": "https://www.youtube.com",
    "google": "https://www.google.com",
    "github": "https://github.com",
    "gmail": "https://mail.google.com",
    "chatgpt": "https://chat.openai.com",
    "wikipedia": "https://www.wikipedia.org",
    "stackoverflow": "https://stackoverflow.com",
    "stack overflow": "https://stackoverflow.com",
    "facebook": "https://www.facebook.com",
    "instagram": "https://www.instagram.com",
    "twitter": "https://twitter.com",
    "x": "https://twitter.com",
    "reddit": "https://www.reddit.com",
    "linkedin": "https://www.linkedin.com",
    "amazon": "https://www.amazon.com",
    "netflix": "https://www.netflix.com",
    "whatsapp web": "https://web.whatsapp.com",
    "maps": "https://maps.google.com",
    "drive": "https://drive.google.com",
    "youtube music": "https://music.youtube.com",
    "spotify web": "https://open.spotify.com",
}

# =====================================================================
#  LAUNCH HELPERS (safe - no shell=True)
# =====================================================================
def _launch_exe(exe, paths=None):
    if paths:
        for p in paths:
            try:
                if p and os.path.isfile(p):
                    subprocess.Popen([p])
                    return True
            except Exception:
                continue
    # 1) Try PATH
    try:
        subprocess.Popen([exe])
        return True
    except FileNotFoundError:
        pass
    except Exception:
        pass
    # 2) ShellExecute fallback (App Paths, registered handlers)
    try:
        os.startfile(exe)  # type: ignore[attr-defined]
        return True
    except Exception:
        return False


def _open_path(path):
    try:
        os.startfile(str(path))
        return True
    except Exception:
        return False


def _open_url(url):
    try:
        webbrowser.open(url)
        return True
    except Exception:
        return False


# =====================================================================
#  MAIN ENTRY
# =====================================================================
def process(text):
    if not text:
        return False, ""
    raw = text.strip()
    low = raw.lower().strip(" .!?")

    # --- EXIT ---
    if low in ("close the assistant", "exit", "quit", "close assistant",
               "goodbye", "bye", "shut down", "stop"):
        return True, "__EXIT__"

    # --- YouTube search ---
    yt = _extract_after(low, ["search youtube for ", "youtube search ",
                              "search on youtube for ", "search youtube "])
    if yt:
        _open_url("https://www.youtube.com/results?search_query=" + _quote(yt))
        return True, "Searching YouTube for {}.".format(yt)

    on_yt = _extract_on(low, " on youtube", prefix_hints=["find ", "search ", "look up "])
    if on_yt:
        _open_url("https://www.youtube.com/results?search_query=" + _quote(on_yt))
        return True, "Searching YouTube for {}.".format(on_yt)

    # --- Google / web search ---
    gs = _extract_after(low, ["search google for ", "google search for ",
                              "search the web for ", "search for ",
                              "google for ", "search "])
    if gs:
        _open_url("https://www.google.com/search?q=" + _quote(gs))
        return True, "Searching Google for {}.".format(gs)

    if low.startswith("google ") and len(low) > 7:
        q = low[7:].strip()
        if q:
            _open_url("https://www.google.com/search?q=" + _quote(q))
            return True, "Searching Google for {}.".format(q)

    # --- Folder ---
    folder_key = _match_folder(low)
    if folder_key is not None:
        target = HOME / folder_key if folder_key else HOME
        if target.exists() and _open_path(target):
            name = folder_key if folder_key else "your home folder"
            return True, "Opening {}.".format(name)
        return True, "I couldn't find the {} folder.".format(folder_key or "home")

    # --- Website ---
    site_key = _match_website(low)
    if site_key:
        _open_url(WEBSITES[site_key])
        return True, "Opening {}.".format(site_key.title())

    # --- Application ---
    app_key = _match_app(low)
    if app_key:
        info = APPS[app_key]
        exe = info["exe"]
        if exe.endswith(":"):
            try:
                subprocess.Popen(["cmd", "/c", "start", "", exe])
                return True, info["reply"]
            except Exception:
                return True, "I couldn't open that."
        ok = _launch_exe(exe, info.get("paths"))
        if ok:
            return True, info["reply"]
        if info.get("url"):
            if _open_url(info["url"]):
                return True, "{} not found, opened the website instead.".format(app_key.title())
        return True, "I couldn't find {} on this PC.".format(app_key)

    return False, ""


# =====================================================================
#  MATCHERS
# =====================================================================
def _match_app(low):
    triggers = ("open ", "launch ", "start ", "run ")
    if not low.startswith(triggers):
        return None
    body = low
    for t in triggers:
        if body.startswith(t):
            body = body[len(t):].strip()
            break
    body = body.rstrip(" .!?")
    if body in APPS:
        return body
    for key in sorted(APPS.keys(), key=len, reverse=True):
        if key in body:
            return key
    return None


def _match_folder(low):
    if not (low.startswith("open ") or low.startswith("go to ") or low.startswith("show ")):
        return None
    body = low
    for t in ("open ", "go to ", "show "):
        if body.startswith(t):
            body = body[len(t):].strip()
            break
    body = body.replace("my ", "").replace(" folder", "").replace(" folders", "").strip(" .!?")
    if body in FOLDERS:
        return FOLDERS[body]
    return None


def _match_website(low):
    if not (low.startswith("open ") or low.startswith("go to ") or low.startswith("visit ")):
        return None
    body = low
    for t in ("open ", "go to ", "visit "):
        if body.startswith(t):
            body = body[len(t):].strip()
            break
    body = body.strip(" .!?")
    if body in WEBSITES:
        return body
    for key in sorted(WEBSITES.keys(), key=len, reverse=True):
        if key == body or body.endswith(" " + key):
            return key
    return None


def _extract_after(low, prefixes):
    for p in prefixes:
        if low.startswith(p):
            rest = low[len(p):].strip(" .!?")
            if rest:
                return rest
    return None


def _extract_on(low, suffix, prefix_hints):
    if not low.endswith(suffix):
        return None
    head = low[:-len(suffix)].strip()
    for p in prefix_hints:
        if head.startswith(p):
            q = head[len(p):].strip(" .!?")
            if q:
                return q
    return None


def _quote(s):
    try:
        from urllib.parse import quote_plus
        return quote_plus(s)
    except Exception:
        return s.replace(" ", "+")