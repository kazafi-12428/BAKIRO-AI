===============================================================
  MBK AI Assistant  -  v1.0
  Voice + Chat Windows PC Assistant
===============================================================

WHAT IT DOES
------------
- Type or speak commands like "open notepad", "open downloads",
  "open youtube", "search Python functions".
- AI-style chat: "what is Python?", "explain cybersecurity" work
  offline. Any other AI question needs an optional API key.
- Speaks replies aloud with Windows text-to-speech.
- Animated dark "anime aura" background.
- SAFE: only whitelisted apps/folders/websites can be opened.
  Unknown sentences are never run as shell commands.


---------------------------------------------------------------
INSTALLATION  (Windows Command Prompt)
---------------------------------------------------------------

1) Install Python 3.10 or newer from https://www.python.org/downloads/
   During install, tick  [x] Add Python to PATH.

2) Open Command Prompt and go to the project folder:

       cd path\to\MBK-AI-Assistant
   Example:
       cd %USERPROFILE%\Desktop\MBK-AI-Assistant

3) (Recommended) Create a virtual environment:

       python -m venv venv
       venv\Scripts\activate

4) Install the required packages:

       python -m pip install --upgrade pip
       python -m pip install -r requirements.txt

   If pyaudio fails, use:
       python -m pip install pipwin
       python -m pipwin install pyaudio

5) Run the assistant:

       python main.py


---------------------------------------------------------------
FILES IN THIS PROJECT
---------------------------------------------------------------
main.py         - Tkinter GUI (run this file)
assistant.py    - Brain: routes to commands, offline KB, optional AI
commands.py     - Safe whitelisted PC commands (apps/folders/search)
voice.py        - Microphone -> text
speech.py       - Text -> speech (background thread)
config.py       - All settings incl. AI API key slot
requirements.txt- Python packages to install
README.txt      - This file


---------------------------------------------------------------
OPTIONAL:  ENABLING AI CHAT
---------------------------------------------------------------
Open config.py and set:

    AI_API_KEY = "sk-your-key-here"

By default this uses OpenAI's endpoint. To use another provider
that speaks the same API (Groq, Together, OpenRouter, local
Ollama with an OpenAI shim, etc.), also change:

    AI_API_BASE = "https://your-provider/v1/chat/completions"
    AI_MODEL    = "your-model-name"

Leave AI_API_KEY = "" to run fully offline. Everything else
(apps, folders, websites, search, voice, TTS) still works.


---------------------------------------------------------------
SUPPORTED COMMANDS  (typed or spoken)
---------------------------------------------------------------
APPS
    open chrome / google chrome
    open edge
    open notepad
    open calculator / calc
    open command prompt / cmd
    open powershell
    open file explorer / explorer
    open settings
    open paint
    open task manager

FOLDERS
    open downloads
    open documents
    open desktop
    open pictures / photos
    open videos
    open music
    open home

WEBSITES
    open youtube / google / github / gmail / chatgpt
    open wikipedia / stackoverflow / facebook / instagram
    open twitter / x / reddit / linkedin / amazon / netflix
    open whatsapp

SEARCH
    search Python functions
    search Google for cybersecurity
    search the web for machine learning
    search YouTube for Python tutorials
    find Python tutorials on YouTube

CHAT (offline knowledge base)
    what is Python?
    explain cybersecurity
    what is AI / machine learning / blockchain / API / Git ...
    hello / how are you / thank you

EXIT
    close the assistant
    exit
    quit
    goodbye


---------------------------------------------------------------
FINAL TEST CHECKLIST
---------------------------------------------------------------
Run:  python main.py

  1. Type:  open notepad
     EXPECT: Notepad opens. Chat says "Opening Notepad."
             Assistant speaks the reply.

  2. Type:  open calculator
     EXPECT: Calculator opens.

  3. Type:  open Chrome
     EXPECT: Chrome opens (or Google in default browser if
             Chrome is not installed).

  4. Type:  open YouTube
     EXPECT: Default browser opens YouTube.

  5. Type:  search Python functions
     EXPECT: Default browser opens a Google search for
             "Python functions".

  6. Click the 🎤 button and say:  "open notepad"
     EXPECT: Status shows "Listening...", your text appears in
             the chat as "(voice)", Notepad opens.

  7. Type:  what is Python?
     EXPECT: Assistant answers from the offline knowledge base.
             No API key required.
     Then type:  how do I reverse a list in Python?
             If NO API key is set, you get:
             "AI chat is not configured yet. ..."
             If API key IS set, you get a real AI answer.

  8. Type:  close the assistant
     EXPECT: Assistant says "Goodbye!" and the window closes
             cleanly after ~0.7 seconds.


---------------------------------------------------------------
TROUBLESHOOTING
---------------------------------------------------------------
"ModuleNotFoundError: No module named 'speech_recognition'"
    Run:  python -m pip install SpeechRecognition

"ModuleNotFoundError: No module named 'pyttsx3'"
    Run:  python -m pip install pyttsx3

"ModuleNotFoundError: No module named 'pyaudio'"
    Run:  python -m pip install pipwin
          python -m pipwin install pyaudio
    The app still runs without pyaudio - you just lose the mic.

"No microphone found"  /  "Microphone unavailable"
    - Check Windows Settings > Privacy > Microphone > allow apps.
    - Make sure a mic is plugged in and set as default device.
    Typed commands still work normally.

"I couldn't understand that."
    - Speak a bit slower and closer to the mic.
    - Requires internet (uses Google's free speech service).

"Speech service unavailable"
    - No internet connection. Typed commands still work.

"No voice / assistant is silent"
    - Check Windows volume and default output device.
    - Set VOICE_ENABLED = True in config.py.

"Chrome opens Google instead"
    - Chrome was not found in the usual install paths, so the
      app fell back to opening google.com in your default browser.

AI replies say "(AI error ...)"
    - Check config.AI_API_KEY, AI_API_BASE, and AI_MODEL.
    - Confirm your key has credit / access to the model.

===============================================================
  Built for a fast demo.  Enjoy MBK AI Assistant!
===============================================================